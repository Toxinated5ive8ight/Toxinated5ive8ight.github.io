document.addEventListener('DOMContentLoaded',()=>{
 const menu=document.querySelector('.menu'), links=document.querySelector('.links');
 if(menu&&links) menu.addEventListener('click',()=>links.classList.toggle('open'));
 const filters=[...document.querySelectorAll('.filter')], cards=[...document.querySelectorAll('[data-category]')];
 filters.forEach(btn=>btn.addEventListener('click',()=>{
   filters.forEach(x=>x.classList.remove('active'));btn.classList.add('active');
   const cat=btn.dataset.filter;
   cards.forEach(card=>card.hidden=!(cat==='all'||card.dataset.category===cat));
 }));
 const search=document.querySelector('#article-search');
 if(search) search.addEventListener('input',()=>{
   const q=search.value.toLowerCase();
   cards.forEach(card=>{const match=card.innerText.toLowerCase().includes(q);card.hidden=card.hidden||!match});
 });
});
